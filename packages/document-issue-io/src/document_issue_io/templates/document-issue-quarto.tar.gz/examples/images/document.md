---
classification: Ac_05
doc_source: WD
document_description: A description of the document that is important
document_name: 06667-MXF-XX-XX-SH-M-20003
format_configuration:
    description_in_filename: false
    include_author_and_checked_by: false
issue_history:
    author: EG
    checked_by: CK
    date: 2020-01-02
    issue_format: cde
    issue_notes: ''
    revision: P01
    status_code: S2
    status_description: Suitable for information
name_nomenclature: project code-originator-volume-level-type-role-number
notes: add notes here
originator: Max Fordham LLP
project_name: A Max Fordham Project
project_number: J4321
roles:
    name: JG
    role: Project Engineer
scale: NTS
size: A4
---

# Images

## A Red Circle

![Some red circle](./media/red-dot.png){width=30mm}

Above we can see an image of a red circle.

{{< pagebreak >}}

## Radiators

::: {layout-ncol=3}
![A Radiator](./media/radiator.jpg){width=30mm}

![Another radiator](./media/radiator-2.jpg){width=30mm}

![Look at that, another radiator!](./media/radiator-3.jpg){width=30mm}
:::

Above we can see many lovely looking radiators.